# IBM FileNet Content Manager 5.5.6 on Container Samples

This repository includes folders and resources to help you install the IBM FileNet Content Manager capabilities. Installation of the capabilities is done with the  operator. 

For information and instructions to install, upgrade, manage, and administer FileNet Content Manager, go to [IBM Knowledge Center](https://www.ibm.com/support/knowledgecenter/SSNW2F_5.5.0/com.ibm.p8.containers.doc/containers.htm).

Legal notice for users of this repository [legal-notice.md](legal-notice.md).
